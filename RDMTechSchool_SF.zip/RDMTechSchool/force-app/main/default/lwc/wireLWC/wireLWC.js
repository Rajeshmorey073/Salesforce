import { LightningElement, api,wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi'; //getRecord is id from module(here we fecth but we can do UPDATE AND EDIT)
import NAME_FIELD from '@salesforce/schema/Contact.Name';
import TITLE_FIELD from '@salesforce/schema/Contact.Title';
import PHONE_FIELD from '@salesforce/schema/Contact.Phone';
import EMAIL_FIELD from '@salesforce/schema/Contact.Email';
import Field from '@salesforce/schema/AccountHistory.Field';

const FIELDS = [NAME_FIELD];
//const FIELDS = [NAME_FIELD, TITLE_FIELD, PHONE_FIELD, EMAIL_FIELD]; //for FIRST

export default class WireLWC extends LightningElement {
/* ********THIS EXAMPLE IS OF PROPERTY & FRO FUNCTION REFER 2ND***********

    @api recordId;
    @wire(getRecord,{recordId:'$recordId',fields:FIELDS})//used adapterId,{adapter config where we pass record id (which record want to fetch and field (which field want to fetch))}
    contact;//Con is propertyOrFun to store above data

    get name() {//getters
        return this.contact.data ? this.contact.data.fields.Name.value : 'N/A';
    }

    get title() {
        return this.contact.data ? this.contact.data.fields.Title.value : 'N/A';
    }

    get phone() {
        return this.contact.data ? this.contact.data.fields.Phone.value : 'N/A';
    }

    get email() {
        return this.contact.data ? this.contact.data.fields.Email.value : 'N/A';
    }
*/
@api recordId;
    record;
    error;

    @wire(getRecord, { recordId: '$recordId', fields: FIELDS })
    wiredAccount({ error, data }) {
        if (data) {
            this.record = data;
            this.error = undefined;
        } else if (error) {
            this.record = undefined;
            this.error = error;
        }
    }

    get name() {
        return this.record ? this.record.fields.Name.value : 'No Name Available';
    }
}