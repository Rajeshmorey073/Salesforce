import { api, LightningElement } from 'lwc';
import ACC_FIELD from '@salesforce/schema/Contact.AccountId';
import NAME_FIELD from '@salesforce/schema/Contact.Name';
import TITLE_FIELD from '@salesforce/schema/Contact.Title';
import PHONE_FIELD from '@salesforce/schema/Contact.Phone';
import EMAIL_FILED from '@salesforce/schema/Contact.Email';

export default class DataServiceLWC extends LightningElement {
   /*  first Demo : place on contact only
   @api recordId;         
    @api objectApiName;
    fields = ['AccountId', 'Name', 'Title', 'Phone', 'Email']; */
  
  /* load any obj ie : generic
    @api recordId;
    renderedCallback() { //testing only
        console.log('Record ID:', this.recordId);  // For debugging purposes
    }*/

/*  Second Demo : place on anywhere only
        @api recordId;         
        @api objectApiName; */

//: place on contact only
        // @api recordId;         
        // @api objectApiName;

        // fields=[ACC_FIELD,NAME_FIELD,TITLE_FIELD,PHONE_FIELD,EMAIL_FILED];
        //OR (optional to above imports check html OR' also )
        @api recordId;         
        @api objectApiName;
}
