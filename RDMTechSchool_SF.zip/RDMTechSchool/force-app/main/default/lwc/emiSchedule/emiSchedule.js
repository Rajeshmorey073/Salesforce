import { LightningElement } from 'lwc';

export default class EmiSchedule extends LightningElement {
    loanAmount = 0;
    interestRate = 0;
    months = 0;
    emiSchedule = [];

    columns = [
        { label: 'Payment Date', fieldName: 'paymentDate' },
        { label: 'EMI Amount', fieldName: 'emiAmount', type: 'currency', typeAttributes: { currencyCode: 'INR' } },
        { label: 'Principal Component', fieldName: 'principalComponent', type: 'currency', typeAttributes: { currencyCode: 'INR' } },
        { label: 'Interest Component', fieldName: 'interestComponent', type: 'currency', typeAttributes: { currencyCode: 'INR' } },
        { label: 'Outstanding Amount', fieldName: 'outstandingAmount', type: 'currency', typeAttributes: { currencyCode: 'INR' } }
    ];

    handleLoanAmountChange(event) {
        this.loanAmount = parseFloat(event.target.value);
    }

    handleInterestRateChange(event) {
        this.interestRate = parseFloat(event.target.value);
    }

    handleMonthsChange(event) {
        this.months = parseInt(event.target.value, 10);
    }

    calculateEMI() {
        if (this.loanAmount > 0 && this.interestRate > 0 && this.months > 0) {
            const emi = this.calculateEmi(this.loanAmount, this.interestRate, this.months);
            const schedule = this.generateSchedule(emi, this.loanAmount, this.interestRate, this.months);
            this.emiSchedule = schedule;
        }
    }

    calculateEmi(principal, rate, term) {
        const monthlyRate = rate / 12 / 100;
        return (principal * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -term));
    }

    generateSchedule(emi, principal, rate, months) {
        const schedule = [];
        let remainingPrincipal = principal;
        let startDate = new Date();
        
        for (let i = 0; i < months; i++) {
            let paymentDate = new Date(startDate);
            paymentDate.setMonth(paymentDate.getMonth() + i);
            const formattedDate = paymentDate.toISOString().split('T')[0];

            const monthlyRate = rate / 12 / 100;
            const interestComponent = remainingPrincipal * monthlyRate;
            const principalComponent = emi - interestComponent;
            remainingPrincipal -= principalComponent;
            const outstandingAmount = remainingPrincipal > 0 ? remainingPrincipal : 0;

            schedule.push({
                id: i + 1,
                paymentDate: formattedDate,
                emiAmount: emi.toFixed(2),
                principalComponent: principalComponent.toFixed(2),
                interestComponent: interestComponent.toFixed(2),
                outstandingAmount: outstandingAmount.toFixed(2)
            });
        }
        return schedule;
    }
}
