import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import CONTACT_OBJECT from '@salesforce/schema/Contact';
import NAME_FIELD from '@salesforce/schema/Contact.LastName';
import Email_FIELD from '@salesforce/schema/Contact.Email';

export default class DataServiceLWC2 extends LightningElement {

    conObject = CONTACT_OBJECT;
    myFields = [NAME_FIELD, Email_FIELD];

    handleConCreated(event) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Record created successfully!',
                message: event.detail.message,
                variant: 'success'
            })
        );
    }
}