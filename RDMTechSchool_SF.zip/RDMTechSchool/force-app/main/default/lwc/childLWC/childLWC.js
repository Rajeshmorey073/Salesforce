import { LightningElement } from 'lwc';

export default class ChildLWC extends LightningElement {
    user="Axis Bank";
// @api user="Axis Bank"; this is for public so we can reassign val check parent.html
}