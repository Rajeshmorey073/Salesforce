import { LightningElement, track } from 'lwc';

export default class ExampleLifecycle extends LightningElement {
    @track message = 'Initializing...';
    @track renderedCount = 0;
    ready=false;
    render=false;
    // Constructor
    constructor() {
        super();
        console.log('Constructor called: Component is being constructed.');
        this.message = 'Component is being constructed.';
    }

    // connectedCallback
    connectedCallback() {
        console.log('connectedCallback called: Component is inserted into the DOM.');
        
        // Simulate a delay
        setTimeout(() => {
            this.message = 'Component is connected to the DOM.';
            this.ready=true;
        }, 5000); // 5 seconds delay
    }

    // renderedCallback
    renderedCallback() {
        console.log('renderedCallback called: Component has been rendered.');
        this.render=true;
        // Simulate a delay
        // setTimeout(() => {
        //     this.renderedCount += 1;
        // }, 10000); // 10 seconds delay
    }
}
