import { LightningElement, track } from 'lwc';
import getContactList from '@salesforce/apex/ContactController.getContactList';

export default class ApexLWC extends LightningElement {
    @track contacts; // Use @track if you want to make sure changes to this property are reactive
    @track error;

    handleLoad() { 
        getContactList()
            .then(result => {
                this.contacts = result; 
                this.error = undefined; // Clear any previous errors
            })
            .catch(error => { 
                this.contacts = undefined; // Clear any previous contacts
                this.error = error; 
            });
    }
}
