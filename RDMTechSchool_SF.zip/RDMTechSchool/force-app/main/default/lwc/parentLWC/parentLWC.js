import { LightningElement } from 'lwc';

export default class ParentLWC extends LightningElement {}