import { LightningElement } from 'lwc';

export default class ListLWC extends LightningElement {

    contacts=[
        {
            id:1,
            Name:'Aman S',
            Title:'VP'
        },{
            id:2,
            Name:'Baman S',
            Title:'SVP' 
        },{
            id:3,
            Name:'Raman S',
            Title:'AVP'
        },{
            id:5,
            Name:'Vaman S',
            Title:'P'
        }
    ]
}