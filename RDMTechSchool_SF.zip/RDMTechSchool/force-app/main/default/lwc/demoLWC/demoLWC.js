import { LightningElement } from 'lwc';

export default class DemoLWC extends LightningElement {}