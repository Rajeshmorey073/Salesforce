import { LightningElement,wire } from 'lwc';
import getContactList from '@salesforce/apex/ContactController.getContactList';
//In this apex method called auto if manual then refer ApexLWC
export default class WireApexLWC extends LightningElement {
    @wire(getContactList)contacts;

    get contactsData() {
        return this.contacts.data ? this.contacts.data : [];
    }

    get hasError() {
        return this.contacts.error;
    }
}