({
	helperMethod : function(component, event) {
		var msg=event.getSource().get("v.label");
        component.set("v.var2",msg);
	}
})