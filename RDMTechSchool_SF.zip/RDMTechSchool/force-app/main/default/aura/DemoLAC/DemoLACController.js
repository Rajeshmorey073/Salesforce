({
	handleClick1 : function(component, event, helper) {
	//	component.set("v.var1","First Button Clicked");//assign val to attribute
		var btn=event.getSource();//onclick event handle 
        var msg= btn.get("v.label"); //can use if(msg=="First Button") set : var1
        component.set("v.var1",msg);
	},
    handleClick2 : function(component, event, helper) {
		//component.set("v.var2","Second Button Clicked");//assign val to attribute
		helper.helperMethod(component, event);
	}
})