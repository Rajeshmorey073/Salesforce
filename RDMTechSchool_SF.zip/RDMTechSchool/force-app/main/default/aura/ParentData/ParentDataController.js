({
	updateParentVar : function(component, event, helper) {
		component.set("v.parentVar","Parent attribute Updated");
	}
})